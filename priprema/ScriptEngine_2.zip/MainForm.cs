﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ScriptEngine
{
    public partial class MainForm : Form
    {
        string Filename;

        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtSource.Text == "")
            {
                MessageBox.Show("No script to process");
                return;
            }
            if (gridOutput.Rows.Count < 1)
            {
                MessageBox.Show("No X, Y values defined");
                return;
            }
            ScriptEngine Engine = null;
            if (btnCSharp.Checked)
                Engine = new ScriptEngine(ScriptEngine.Languages.CSharp);
            if (btnJScript.Checked)
                Engine = new ScriptEngine(ScriptEngine.Languages.JScript);
            if (btnVBasic.Checked)
                Engine = new ScriptEngine(ScriptEngine.Languages.VBasic);
            if (btnFSharp.Checked)
                Engine = new ScriptEngine(ScriptEngine.Languages.FSharp);
            if (Engine != null)
            {
                string code = "";
                foreach (string line in txtSource.Lines)
                {
                    if (Engine.Language == ScriptEngine.Languages.FSharp) 
                        code += "        " + line + "\r\n";
                    else
                        code += line + "\r\n";
                }
                Engine.Code = code;
                Engine.AddVariable("X");
                Engine.AddVariable("Y");
                if (Engine.Compile())
                {
                    foreach (DataGridViewRow row in gridOutput.Rows)
                    {
                        if (row.Cells[0].Value != null)
                        {
                            Engine.SetVariable("X", Double.Parse(row.Cells[0].Value.ToString()));
                            Engine.SetVariable("Y", Double.Parse(row.Cells[1].Value.ToString()));
                            double result = Engine.Evaluate();
                            row.Cells[2].Value = result;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Compiler message: " + Engine.Messages[0]);
                }
                Engine.Unload();
                Engine = null;
            }
            else
            {
                MessageBox.Show("Unable to allocate scripting engine");
                return;
            }
        }

        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            if (dlgFileOpen.ShowDialog() == DialogResult.OK)
            {
                Filename = dlgFileOpen.FileName;
                lblFilename.Text = Filename;
                txtSource.LoadFile(Filename, RichTextBoxStreamType.PlainText);
            }
        }

        private void mnuFileSave_Click(object sender, EventArgs e)
        {
            if ((Filename == null) || (Filename == ""))
                mnuFileSaveAs_Click(sender, e);
            else
                txtSource.SaveFile(Filename, RichTextBoxStreamType.PlainText);
        }

        private void mnuFileSaveAs_Click(object sender, EventArgs e)
        {
            if (dlgFileSave.ShowDialog() == DialogResult.OK)
            {
                Filename = dlgFileSave.FileName;
                lblFilename.Text = Filename;
                txtSource.SaveFile(Filename, RichTextBoxStreamType.PlainText);
            }
        }
    }
}

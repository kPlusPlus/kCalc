let rec Fac n =
    match n with
    | z when z <= 1.0 -> 1.0
    | z -> z * (Fac (z - 1.0))
Result <- X * Fac Y
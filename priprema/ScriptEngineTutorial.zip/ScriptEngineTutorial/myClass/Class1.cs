using System;

namespace myNotClass
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	/// 
	public delegate void myEventHandle(int n);
	public class Class1
	{
		public event myEventHandle myEvent;

		public Class1()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public void Method1(string text)
		{
			System.Windows.Forms.MessageBox.Show(text);
		}
	}
}

using System;
using System.Collections;
using System.Reflection;
using Microsoft.Vsa;
using Microsoft.VisualBasic.Vsa;

namespace ScriptEngineTutorial
{
	/// <summary>
	/// Summary description for TestVsaSite.
	/// </summary>
	public class TestVsaSite : Microsoft.Vsa.IVsaSite
	{
		private System.Collections.Hashtable eventInstance;

		public TestVsaSite()
		{
			eventInstance = new Hashtable();
		}

		public void AddEvent(string name, string type, object instance, bool events)
		{
			eventInstance.Add(name, instance);
		}

		public void GetCompiledState(out byte[] pe, out byte[] debugInfo)
		{
			pe = null;
			debugInfo = null;
		}

		public object GetEventSourceInstance(string itemName, string eventSourceName)
		{
			return eventInstance[eventSourceName];
		}

		public object GetGlobalInstance(string name)
		{
			return (object)null;
		}

		public void Notify(string notify, object info)
		{
		}

		public bool OnCompilerError(IVsaError error)
		{
			return false;
		}
	}

	/// <summary>
	/// Summary description for TestVsaScriptHost.
	/// </summary>
	public class TestVsaScriptHost
	{
		private Microsoft.Vsa.IVsaEngine		m_vbEngine = null;
		private Microsoft.Vsa.IVsaItems			m_vbItems = null;
		private Microsoft.Vsa.IVsaCodeItem		m_vbScript = null;
		private Microsoft.Vsa.IVsaReferenceItem m_vbSystemRef = null;
		private Microsoft.Vsa.IVsaReferenceItem m_vbTempRef = null;
		private ScriptEngineTutorial.TestVsaSite m_vbSite = null;

		public TestVsaScriptHost(string moniker, string nameSpace)
		{
			string strEx = "";

			try
			{
				m_vbEngine = new Microsoft.VisualBasic.Vsa.VsaEngine();
				m_vbEngine.RootMoniker = moniker;
				m_vbEngine.Site = new TestVsaSite();
				m_vbSite = (TestVsaSite)m_vbEngine.Site;
				m_vbEngine.InitNew();
				m_vbEngine.RootNamespace = nameSpace;
				m_vbEngine.Name = nameSpace;

				m_vbItems = m_vbEngine.Items;
				m_vbScript = (Microsoft.Vsa.IVsaCodeItem)m_vbItems.CreateItem(nameSpace, Microsoft.Vsa.VsaItemType.Code, Microsoft.Vsa.VsaItemFlag.Module);
//				m_vbItems.CreateItem("System", Microsoft.Vsa.VsaItemType.Reference, Microsoft.Vsa.VsaItemFlag.None);

				this.AddReference("System", "System.dll");

				SetupImports("System");
			}
			catch (System.Exception ex)
			{
				strEx = ex.Message;
			}
		}

		// Call this function to add code to the script
		public void AddCode(string strCode)
		{
			string strTempCode = this.scriptSrc;
			this.scriptSrc = strTempCode.Insert(strTempCode.LastIndexOf("End Module"), strCode + "\r");
		}

		public void AddObject(string name, string type, object instance, string assemblyName)
		{
			m_vbScript.AddEventSource(name, type);
			m_vbSite.AddEvent(name, type, instance, true);
			this.AddReference(name + "Ref", assemblyName);
			this.SetupImports(type.Split('.')[0]);
		}

		public void AddReference(string name, string assemblyName)
		{
			string strEx = "";
			try
			{
				m_vbTempRef = (IVsaReferenceItem)m_vbItems.CreateItem(name, VsaItemType.Reference, VsaItemFlag.None);
				m_vbTempRef.AssemblyName = assemblyName;
			}
			catch (System.Exception ex)
			{
				strEx = ex.Message;
			}
		}

		public void Compile()
		{
			string strEx = "";
			try
			{
				if (m_vbEngine.IsRunning)
					m_vbEngine.Reset();

				if (m_vbEngine.Compile())
					this.Run();
				else
				{
					int i = 0;
				}
			}
			catch (System.Exception ex)
			{
				strEx = ex.Message;
				throw(new Exception(strEx));
			}
		}

		public void Run()
		{
			m_vbEngine.Compile();
			m_vbEngine.Run();
		}

		public object Invoke(string moduleName, string methodName, object[] args)
		{
			string fullName;
			System.Type modType;
			System.Reflection.MethodInfo method;

			if (!m_vbEngine.IsRunning)
				this.Run();

			fullName = m_vbEngine.RootNamespace + "." + moduleName;

			try
			{
				modType = m_vbEngine.Assembly.GetType(fullName, true, true);
				method = modType.GetMethod(methodName);

				if (method != null)
					return method.Invoke(null, args);
			}
			catch (System.Exception ex)
			{
				fullName = ex.Message;
			}

			return null;
		}

		private void SetupImports(string Type)
		{
			string strScript = "imports " + Type;
			strScript += "\r\n";
			this.scriptSrc = strScript + this.scriptSrc;
		}

		public string scriptSrc
		{
			get
			{
				return m_vbScript.SourceText;
			}
			set
			{
				m_vbScript.SourceText = value;
			}
		}
	}
}
